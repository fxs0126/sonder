# Generated from 'IBCarbonRuntime.h'

kIBCarbonRuntimeCantFindNibFile = -10960
kIBCarbonRuntimeObjectNotOfRequestedType = -10961
kIBCarbonRuntimeCantFindObject = -10962
