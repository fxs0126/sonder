.. cmake-module:: ../../Modules/FindPostgreSQL.cmake
