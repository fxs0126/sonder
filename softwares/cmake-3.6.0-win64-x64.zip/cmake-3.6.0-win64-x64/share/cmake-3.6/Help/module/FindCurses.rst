.. cmake-module:: ../../Modules/FindCurses.cmake
